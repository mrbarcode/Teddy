clear
cd module
blue='\033[34;1m'
green='\033[32;1m'  
purple='\033[35;1m'
cyan='\033[36;1m'
red='\033[31;1m'
white='\033[37;1m'                                           
yellow='\033[33;1m'
sleep 1
echo $red
echo "
 ______    ___  ___    ___    __ __ 
|      |  /  _]|   \  |   \  |  |  |
|      | /  [_ |    \ |    \ |  |  |
|_|  |_||    _]|  D  ||  D  ||  ~  |
  |  |  |   [_ |     ||     ||___, |
  |  |  |     ||     ||     ||     |
  |__|  |_____||_____||_____||____/ 
                                    
"
echo ""
echo "\033[34;1m[$]\033[36;1m============================\033[34;1m[$]"
echo "\033[32;1mCoder : Mr.Barcode"
echo "\033[37;1mTnx: Mr.Barcode"
echo "\033[35;1mversion Tools: 1"
echo "\033[35;mmyTeam : Null_sec"
echo "\033[33;mmytelegram : https://t.me/unknownbarcode" 
echo "\033[36;ssecurity is very low"
echo "\033[34;1m[$]\033[36;1m============================\033[34;1m[$]"
echo ""
echo "\033[32;sselect tools?:"
echo "\033[36;1m"
echo "[===============================================[>"
echo $red "1.> CC Carding"
echo "[===============================================]>"
echo $red "2.> 10 min mail"
echo "[===============================================]>"
echo $red "3.> SpamSms"
echo "[===============================================]>"
echo $red "4.> DvrHacking"
echo "[===============================================]>"
echo $red "5.> ahmyth rat"
echo "[===============================================]>"
echo $red "6.> pinky"
echo "[===============================================]>"
echo $red "7.> spyrat"
echo "[===============================================]>"
echo $red "8.> VbugMaker"
echo "[===============================================]>"
echo $red "9.> REDHAWK"
echo "[===============================================]>"
echo $red "10.> Torshammer"
echo "[===============================================]>"
echo $red "11.> Hunner"
echo "[===============================================]>"
echo $red "12.> Weeman"
echo "[===============================================]>"
echo $red "13.> A-Rat"
echo "[===============================================]>"
echo $red "14.> Youtube downloader"
echo "[===============================================]>"
echo $red "15.> WAScan"
echo "[===============================================]>"
echo $red "16.> Xerxes"
echo "[===============================================]>"
echo $red "17.> IPGeoLocation"
echo "[===============================================]>"
echo $red "18.> OWScan"
echo "[===============================================]>"
echo $red "19.> SocialFish"
echo "[===============================================]>"
echo $red "20.> Cupp"
echo "[===============================================]>"
echo $red "21.> TheFatRat"
echo "[===============================================]>"
echo $red "22.> Bruteforce gmail"
echo "[===============================================]>"
echo $red "23.> Ezsploit"
echo "[===============================================]>"
echo $red "24.> Killer"
echo "[===============================================]>"
echo $red "25.> OSIF"
echo "[===============================================]>"
echo $red "26.> BForce"
echo "[===============================================]>"
echo $red "27.> SMBrute"
echo "[===============================================]>"
echo $red "28.> WPHunter"
echo "[===============================================]>"
echo $red "29.> Zilcorili"
echo "[===============================================]>"
echo $red "30.> fbbrute"
echo "[===============================================]>"
echo $red "31.> Brutal"
echo "[===============================================]>"
echo $red "32.> BruteSploit"
echo "[===============================================]>"
echo $red "33.> Vegile"
echo "[===============================================]>"
echo $red "34.> TrackUrl"
echo "[===============================================]>"
echo $red "35.> IP Locator"
echo "[===============================================]>"
echo $red "36.> Admin Finder"
echo "[===============================================]>"
echo $red "37.> Xerosploit"
echo "[===============================================]>"
echo $red "38.> Setoolkit"
echo "[===============================================]>"
echo $red "39.> Metasploit"
echo "[===============================================]>"
echo $red "40.> Instahack"
echo "[===============================================]>"
echo $red "41.> Hatch"
echo "[===============================================]>"

echo "\033[32;1m"
read -p "root@T00Ls-B6A1R32CO1D~#" bro


if [ $bro = 1 ] || [ $bro = 1 ]
then
clear
php carding.php
fi


if [ $bro = 2 ] || [ $bro = 2 ]
then
clear
figlet "Mr.Barcode" | Teddy Tools
git clone https://github.com/kiansheik/10-minute-mail
mv 10-minute-mail $HOME
cd $HOME/10-minute-mail
python2 10minmail.py
fi

if [ $bro = 3 ] || [ $bro = 3 ]
then
clear
figlet "Mr.Barcode" | Teddy Tools
git clone https://github.com/KANG-NEWBIE/SpamSms
mv SpamSms $HOME
cd $HOME/SpamSms
python main.py
fi

if [ $bro = 4 ] || [ $bro = 4 ]
then
clear
figlet "Mr.Barcode" | Teddy Tools
git clone https://github.com/ezelf/CVE-2018-9995_dvr_credentials
mv CVE-2018-9995_dvr_credentials $HOME
cd $HOME/CVE-2018-9995_dvr_credentials
pip install -r requirements.txt
python getDVR_Credentials.py -h
fi

if [ $bro = 5 ] || [ $bro = 5 ]
then
clear
figlet "Mr.Barcode" | Teddy Tools
git clone https://github.com/AhMyth/AhMyth-Android-RAT.git
mv AhMyth-Android-RAT/AhMyth-Server $HOME
cd $HOME/AhMyth-Android-RAT/AhMyth-Server
npm start
fi

if [ $bro = 6 ] || [ $bro = 6 ]
then
clear
figlet "Mr.Barcode" | Teddy Tools
git clone https://github.com/davidtavarez/pinky
mv pinky $HOME
cd $HOME/pinky
php pinky.php
fi

if [ $bro = 7 ] || [ $bro = 7 ]
then
clear
figlet "Mr.Barcode" | Teddy Tools
git clone https://github.com/M4sc3r4n0/spyrat.git
mv spyrat $HOME
cd $HOME/spyrat
python listener.py
fi

if [ $bro = 8 ] || [ $bro = 8 ]
then
clear
toilet "Mr.Barcode"
python2 anvima.py
fi

if [ $bro = 9 ] || [ $bro = 9 ]
then
clear
toilet -f standard -F gay "Mr.Barcode" 
sleep 3
apt update
apt install git
apt install php
git clone https://github.com/Tuhinshubhra/RED_HAWK
mv RED_HAWK $HOME
cd $HOME/RED_HAWK
chmod +x rhawk.php
php rhawk.php
fi

if [ $bro = 10 ] || [ $bro = 10 ]
then
clear
toilet -f standard -F gay "Mr.Barcode" 
apt update
apt install git
apt install tor
git clone https://github.com/dotfighter/torshammer.git
mv torshammer $HOME
cd $HOME/torshammer
read -p "Masukan Target==>:" target
python2 torshammer.py -T -t target
fi

if [ $bro = 11  || [ $bro = 11 ]
then
clear
toilet -f standard -F gay "Mr.Barcode" 
apt update
apt install git
git clone https://github.com/b3-v3r/Hunner.git
mv Hunner $HOME
cd $HOME/Hunner
chmod +x hunner.py
python2 hunner.py
fi

if [ $bro = 12 ] || [ $bro = 12 ]
then
clear
figlet "Mr.Barcode" | Teddy Tools
sleep 1 
apt install git
apt install php
git clone https://github.com/evait-security/weeman.git
mv weeman $HOME
cd $HOME/weeman
python2 weeman.py
fi

if [ $bro = 13 ] || [ $bro = 13 ]
then
clear
figlet "Mr.Barcode" | Teddy Tools
sleep 1
git clone https://github.com/Xi4u7/A-Rat.git
mv A-Rat $HOME
cd $HOME/A-Rat
python2 A-Rat.py
fi

if [ $bro = 14 ] || [ $bro = 14 ]
then
clear
cowsay -f kiss.cow "MrBarcode" | Teddy Tools
figlet "Mr.Barcode" | Teddy Tools
sleep 1
apt update && apt upgrade
apt install pip
pkg install python
pkg install python2
pip install mps_youtube
pip install youtube_dl
pkg install mpv
mpsyt
fi

if [ $bro = 15 ] || [ $bro = 15 ]
then
clear
cowsay -f kiss.cow "MrBarcode" | Teddy Tools
figlet "Mr.Barcode" | Teddy Tools
sleep 1
apt update && apt upgrade
apt install python2
apt install git
pip2 install -r requirements.txt
git clone https://github.com/m4II0k/WAScan.git
mv WAScan $HOME
cd $HOME/WAScan
pip2 install -r requirements.txt
clear
chmod +x wascan.py
python2 wascan.py 
fi

if [ $bro = 16 ] || [ $bro = 16 ]
then
clear
toilet -f slant --gay "Mr.Barcode"
apt update && apt upgrade
apt install git
apt install clang
git clone https://github.com/zanyarjamal/xerxes
mv xerxes $HOME
cd $HOME/xerxes
clang xerxes.c -o xerxes
clear
read -p "[masukanWebsiteTarget]>" target
./xerxes target 80
fi

if [ $bro = 17 ] || [ $bro = 17 ]
then
clear
figlet "Mr.Barcode" | Teddy Tools
sleep 3
apt install git
apt install python
apt install python2
git clone https://github.com/maldevel/IPGeoLocation.git
mv IPGeoLocation $HOME
cd $HOME/IPGeoLocation
chmod +x ipgeoLocation.py
pip install -r requirements.txt
python ipgeolocation.py -m
read -p "[Masukan IP/website]>" target
python ipgeolocation.py -t target
fi

if [ $bro = 18 ] || [ $bro = 18 ]
then
clear
cowsay -f kiss.cow "MrBarcode" | Teddy Tools
figlet "Mr.Barcode" | Teddy Tools
sleep 1
apt update && apt upgrade
apt install git
apt install php
git clone https://github.com/Gameye98/OWScan.git
mv OWScan $HOME
cd $HOME/OWScan
php owscan.php
fi

if [ $bro = 19 ] || [ $bro = 19 ]
then
clear
toilet -f standard -F gay "Mr.Barcode"
sleep 5
pkg install php
pkg install python2
pkg install git
pkg install curl
git clone https://github.com/Lexiie/SocialFish.git
mv SocialFish $HOME
cd $HOME/SocialFish
pip2 install wget
python2 SocialFish.py
fi

if [ $bro = 20 ] || [ $bro = 20 ]
then
clear
toilet -f standard -F gay "Mr.Barcode"
sleep 5
pkg install git
pkg install python2
git clone https://github.com/mebus/cupp.git
mv cupp $HOME
cd $HOME/cupp
python2 cupp.py
fi

if [ $bro = 21 ] || [ $bro = 21 ]
then
clear
"Mr.Barcode"
sleep 1
apt-get update && apt-get upgrade
apt-get install git
git clone https://github.com/Screetsec/TheFatRat.git
mv TheFatRat $HOME
cd $HOME/TheFatRat
chmod +x setup.sh 
./setup.sh
fi

if [ $bro = 22 ] || [ $bro = 22 ]
then
clear
toilet -f big -F gay "Mr.Barcode"
sleep 1
apt update && apt upgrade
apt install git
git clone https://github.com/JamesAndresCM/Brute_force_gmail
mv Brute_force_gmail $HOME
cd $HOME/Brute_force_gmail
ls
fi

if [ $bro = 23 ] || [ $bro = 23 ]
then
clear
toilet -f big -F gay "Mr.Barcode"
sleep 1
apt update
apt upgrade
apt install git
git clone https://github.com/rand0m1ze/ezsploit
mv ezsploit $HOME
cd $HOME/ezsploit
bash ezsploit.sh
fi

if [ $bro = 24 ] || [ $bro = 24 ]
then
clear
toilet -f big -F gay "Mr.Barcode"
sleep 1
apt update 
apt upgrade
apt install git 
apt install php
git clone https://github.com/whackashoe/killr.git
mv killr $HOME
cd $HOME/killr
php server.php
fi

if [ $bro = 25 ] || [ $bro = 25 ]
then
clear
toilet -f big -F gay "Mr.Barcode"
sleep 1
apt update 
apt upgrade
apt install git 
apt install python2
git clone https://github.com/CiKu370/OSIF
mv OSIF $HOME
cd $HOME/OSIF
python2 osif.py
fi

if [ $bro = 26 ] || [ $bro = 26 ]
then
clear
toilet -f big -F gay "Mr.Barcode"
sleep 1
apt update 
apt upgrade
apt install git 
apt install python2
git clone https://github.com/YukersCreew/BForce
mv BForce $HOME
cd $HOME/BForce
python2 Yukers.py
fi

if [ $bro = 27 ] || [ $bro = 27 ]
then
clear
toilet -f big -F gay "Mr.Barcode"
sleep 1
apt update 
apt upgrade
apt install git 
apt install python2
git clone https://github.com/m4ll0k/SMBrute
mv SMBrute $HOME
cd $HOME/SMBrute
python2 smbrute.py
fi

if [ $bro = 28 ] || [ $bro = 28 ]
then
clear
toilet -f big -F gay "Mr.Barcode"
sleep 1
apt update 
apt upgrade
apt install git 
apt install perl
git clone https://github.com/aryanrtm/WP-Hunter
mv WP-Hunter $HOME
cd $HOME/WP-Hunter
perl wphunter.pl
fi

if [ $bro = 29 ] || [ $bro = 29 ]
then
clear
toilet -f big -F gay "Mr.Barcode"
sleep 1
apt update 
apt upgrade
apt install git
apt install ruby
git clone https://github.com/b3-v3r/Zilcorili
mv Zilcorili $HOME
cd $HOME/Zilcorili
ruby main.rb
fi

if [ $bro = 30 ] || [ $bro = 30 ]
then
clear
toilet -f big -F gay "Mr.Barcode"
sleep 1
apt update 
apt upgrade
apt install git
apt install python2
git clone https://github.com/verluchie/fbbrute
mv fbbrute $HOME
cd $HOME/fbbrute
python2 fbbrute.py
fi

if [ $bro = 31 ] || [ $bro = 31 ]
then
clear
toilet -f big -F gay "Mr.Barcode"
sleep 1
apt update 
apt upgrade
apt install git
git clone https://github.com/Screetsec/Brutal
mv  Brutal $HOME
cd $HOME/Brutal
sh Brutal.sh
fi

if [ $bro = 32 ] || [ $bro = 32 ]
then
clear
toilet -f big -F gay "Mr.Barcode"
sleep 1
apt update 
apt upgrade
apt install git
git clone https://github.com/Screetsec/BruteSploit
mv BruteSploit $HOME
cd $HOME/BruteSploit
chmod 777 Brutesploit
./Brutesploit
fi

if [ $bro = 33 ] || [ $bro = 33 ]
then
clear
toilet -f big -F gay "Mr.Barcode"
sleep 1
apt update 
apt upgrade
apt install git
git clone https://github.com/Screetsec/Vegile
mv Vegile $HOME
cd $HOME/Vegile
chmod 777 Vegile
./Vegile
fi

if [ $bro = 34 ] || [ $bro = 34 ]
then
clear
toilet -f big -F gay "Mr.Barcode"
sleep 1
apt update 
apt upgrade
apt install git
git clone https://github.com/zanyarjamal/TrackUrl
mv TrackUrl $HOME
cd $HOME/TrackUrl
sh TrackUrl.sh
fi

if [ $bro = 35 ] || [ $bro = 35 ]
then
clear
toilet -f big -F gay "Mr.Barcode"
sleep 1
apt update 
apt upgrade
apt install perl
apt install git
git clone https://github.com/zanyarjamal/IP-Locator
mv IP-Locator $HOME
cd $HOME/IP-Locator
perl ip-locator.pl
fi

if [ $bro = 36 ] || [ $bro = 36 ]
then
clear
toilet -f big -F gay "Mr.Barcode"
sleep 1
apt update 
apt upgrade
apt install 
apt install git
git clone https://github.com/the-c0d3r/admin-finder.git
mv admin-finder $HOME
cd $HOME/admin-finder
python2 admin-finder.py
fi

if [ $bro = 37 ] || [ $bro = 37 ]
then
clear
toilet -f big -F gay "Mr.Barcode"
sleep 1
apt update 
apt upgrade
apt install python2
apt install git
git clone https://github.com/LionSec/xerosploit
mv xerosploit $HOME
cd $HOME/xerosploit
python2 install.py
fi

if [ $bro = 38 ] || [ $bro = 38 ]
then
clear
toilet -f big -F gay "Mr.Barcode"
sleep 1
apt update 
apt upgrade
apt install git
git clone https://github.com/Techzindia/setoolkit-for-termux
mv setoolkit-for-termux $HOME
cd $HOME/setoolkit-for-termux
sh setoolkit.sh
fi

if [ $bro = 39 ] || [ $bro = 39 ]
then
clear
toilet -f big -F gay "Mr.Barcode"
sleep 1
apt update 
apt upgrade
apt install git
git clone https://github.com/Techzindia/Metasploit_For_Termux
mv Metasploit_For_Termux $HOME
cd $HOME/Metasploit_For_Termux
sh metasploitTechzindia.sh
fi

if [ $bro = 40 ] || [ $bro = 40 ]
then
clear
toilet -f big -F gay "Mr.Barcode"
sleep 1
apt update 
apt upgrade
apt install python2 
apt install git
git clone https://github.com/avramit/Instahack
mv Instahack $HOME
cd $HOME/Instahack
python2 hackinsta.py
fi

if [ $bro = 41 ] || [ $bro = 41 ]
then
clear
toilet -f big -F gay "Mr.Barcode"
sleep 1
apt update 
apt upgrade
apt install python2 
apt install git
git clone https://github.com/MetaChar/Hatch
mv Hatch $HOME
cd $HOME/Hatch
python2 main.py
fi



if [ $bro = 0 ] || [ $bro = 00 ]
then
echo "\033[32;my team : null_sec"
sleep 1
echo "\033[33;coded by mrbarcode"
sleep 1
exit
fi

